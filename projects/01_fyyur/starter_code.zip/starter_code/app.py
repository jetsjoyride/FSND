#----------------------------------------------------------------------------#
# Imports
#----------------------------------------------------------------------------#

import json
import dateutil.parser
import babel
from flask import Flask, render_template, request, Response, flash, redirect, url_for
from flask_moment import Moment
from flask_sqlalchemy import SQLAlchemy
import logging
from flask_migrate import Migrate
from logging import Formatter, FileHandler
from flask_wtf import FlaskForm
from forms import *
from datetime import datetime, timezone
from sqlalchemy.ext.hybrid import hybrid_property, hybrid_method

#----------------------------------------------------------------------------#
# App Config.
#----------------------------------------------------------------------------#

app = Flask(__name__)
moment = Moment(app)
app.config.from_object('config')
db = SQLAlchemy(app)

#----------------------------------------------------------------------------#
# Setup Migrations
#----------------------------------------------------------------------------#
migrate = Migrate(app,db)

#----------------------------------------------------------------------------#
# Setup Database Classes
#----------------------------------------------------------------------------#

class Venue(db.Model):
    __tablename__ = 'venue'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, nullable=False)
    genres = db.Column(db.String(120))
    address = db.Column(db.String(120))
    city = db.Column(db.String(120))
    state = db.Column(db.String(120))
    phone = db.Column(db.String(120),nullable=False)
    website = db.Column(db.String(1024))
    facebook_link = db.Column(db.String(120))
    seeking_talent = db.Column(db.Boolean())
    seeking_description = db.Column(db.String(1024))
    image_link = db.Column(db.String(500))
    shows = db.relationship('Show', backref='venue', cascade='all, delete')

    def __repr__(self):
        return f"""<Venue {self.id} {self.name}>"""

    @hybrid_property
    def past_shows(self):
        now = datetime.now()
        return Show.query.filter(Show.start_time<now).filter(Show.venue_id==self.id).all()

    @hybrid_property
    def past_shows_count(self):
        now = datetime.now()
        return Show.query.filter(Show.start_time<now).filter(Show.venue_id==self.id).count()

    @hybrid_property
    def upcoming_shows(self):
        now = datetime.now()
        return Show.query.filter(Show.start_time>=now).filter(Show.venue_id==self.id).all()

    @hybrid_property
    def upcoming_shows_count(self):
        now = datetime.now()
        return Show.query.filter(Show.start_time>=now).filter(Show.venue_id==self.id).count()

    @hybrid_property
    def genre_list(self):
        return self.genres.strip('{\"}').replace('\"','').split(',')

class Artist(db.Model):
    __tablename__ = 'artist'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, nullable=False)
    city = db.Column(db.String(120))
    state = db.Column(db.String(120))
    phone = db.Column(db.String(120),nullable=False)
    genres = db.Column(db.String(120))
    image_link = db.Column(db.String(500))
    facebook_link = db.Column(db.String(120))
    website = db.Column(db.String(1024))
    seeking_venue = db.Column(db.Boolean())
    seeking_description = db.Column(db.String(1024))
    shows = db.relationship('Show', backref='artist', cascade='all, delete')

    def __repr__(self):
        return f"""<Artist {self.id} {self.name}>"""

    @hybrid_property
    def past_shows(self):
        now = datetime.now()
        return Show.query.filter(Show.start_time<now).filter(Show.artist_id==self.id).all()

    @hybrid_property
    def past_shows_count(self):
        now = datetime.now()
        return Show.query.filter(Show.start_time<now).filter(Show.artist_id==self.id).count()

    @hybrid_property
    def upcoming_shows(self):
        now = datetime.now()
        return Show.query.filter(Show.start_time>=now).filter(Show.artist_id==self.id).all()

    @hybrid_property
    def upcoming_shows_count(self):
        now = datetime.now()
        return Show.query.filter(Show.start_time>=now).filter(Show.artist_id==self.id).count()

    @hybrid_property
    def genre_list(self):
        return self.genres.strip('{\"}').replace('\"','').split(',')

# Many-to-many relationships are defined before class definitions for a table
class Show(db.Model):
    __tablename__ = 'show'
    id = db.Column(db.Integer, primary_key=True)
    venue_id = db.Column(db.Integer, db.ForeignKey('venue.id'),
        nullable=False)
    artist_id = db.Column(db.Integer, db.ForeignKey('artist.id'),
        nullable=False)
    start_time = db.Column(db.DateTime, nullable=False)

    def __repr__(self):
        return f"""<Show ID {self.id}: {self.artist.name} at {self.venue.name} on {self.start_time}>"""

    @hybrid_property
    def artist_name(self):
        return self.artist.name

    @hybrid_property
    def artist_image_link(self):
        return self.artist.image_link

    @hybrid_property
    def venue_name(self):
        return self.venue.name

    @hybrid_property
    def venue_image_link(self):
        return self.venue.image_link

#----------------------------------------------------------------------------#
# Filters.
#----------------------------------------------------------------------------#

def format_datetime(value, format='medium'):
  date = dateutil.parser.parse(value.strftime("%a %m, %d, %y %X"))
  if format == 'full':
      format="EEEE MMMM, d, y 'at' h:mma"
  elif format == 'medium':
      format="EE MM, dd, y h:mma"
  return babel.dates.format_datetime(date, format)

app.jinja_env.filters['datetime'] = format_datetime

#----------------------------------------------------------------------------#
# Controllers.
#----------------------------------------------------------------------------#

@app.route('/')
def index():
  return render_template('pages/home.html')


@app.route('/venues')
def venues():
    data=[]
    now = datetime.now()
    locations = Venue.query.with_entities(Venue.city, Venue.state).group_by(Venue.city, Venue.state).all()
    for location in locations:
        dataObj={}
        dataObj['city'] = location.city
        dataObj['state'] = location.state
        venues = Venue.query.with_entities(Venue.id, Venue.name).filter_by(city = location.city, state = location.state).all()
        dataObj['venues'] = []
        for venue in venues:
            num_upcoming_shows = Show.query.filter(Show.start_time>now).filter(Show.venue_id==venue.id).count()
            dataObj['venues'].append(
                {'id':venue.id,
                'name':venue.name,
                'num_upcoming_shows':num_upcoming_shows
                })
        data.append(dataObj)
    return render_template('pages/venues.html', areas=data);

@app.route('/venues/search', methods=['POST'])
def search_venues():
  # seach for Hop should return "The Musical Hop".
  # search for "Music" should return "The Musical Hop" and "Park Square Live Music & Coffee"
    search_term = request.form.get('search_term','')
    results = Venue.query.filter(Venue.name.ilike('%'+search_term+'%'))
    response={
        "count": results.count(),
        "data": results
    }
    return render_template('pages/search_venues.html', results=response, search_term=request.form.get('search_term', ''))

@app.route('/venues/<int:venue_id>')
def show_venue(venue_id):
  # shows the venue page with the given venue_id
    venue = Venue.query.get(venue_id)
    return render_template('pages/show_venue.html', venue=venue)

#  ----------------------------------------------------------------
#  Create Venue
#  ----------------------------------------------------------------

@app.route('/venues/create', methods=['GET'])
def create_venue_form():
    form = VenueForm()
    return render_template('forms/new_venue.html', form=form)

@app.route('/venues/create', methods=['POST'])
def create_venue_submission():
    error = False
    try:
        data = {
            'name':request.form.get('name'),
            'city':request.form.get('city'),
            'state':request.form.get('state'),
            'address':request.form.get('address'),
            'phone':request.form.get('phone'),
            'website':request.form.get('website'),
            'image_link':request.form.get('image_link'),
            'seeking_talent':request.form.get('seeking_talent')=='y',
            'seeking_description':request.form.get('seeking_description'),
            'facebook_link':request.form.get('facebook_link'),
            'image_link':request.form.get('image_link'),
            'genres':request.form.getlist('genre_list')
        }
        new_venue = Venue(**data)
        db.session.add(new_venue)
        db.session.flush()
        new_venue_id = new_venue.id
        db.session.commit()
    except:
        error = True
        db.session.rollback()
    finally:
        db.session.close()
    if not error:
        flash('Venue ' + request.form['name'] + ' was successfully listed!')
        return redirect(url_for('show_venue', venue_id=new_venue_id))
    flash('An error occurred. Venue ' + data.name + ' could not be listed.')
    return render_template('pages/home.html')


@app.route('/venues/<int:venue_id>/delete', methods=['POST'])
def delete_venue(venue_id):
    error = False
    print("trying to delete")
    try:
        venue = Venue.query.get(venue_id)
        db.session.delete(venue)
        db.session.commit()
    except:
        db.session.rollback()
        error = True
    finally:
        db.session.close()

    if not error:
        flash('Venue successfully deleted')
    else:
        flash('An error occurred trying to delete venue')
    return render_template('pages/home.html')

#  Artists
#  ----------------------------------------------------------------
@app.route('/artists')
def artists():
  artists = Artist.query.all()
  return render_template('pages/artists.html', artists=artists)

@app.route('/artists/search', methods=['POST'])
def search_artists():
    # seach for "A" should return "Guns N Petals", "Matt Quevado", and "The Wild Sax Band".
    # search for "band" should return "The Wild Sax Band".
    search_term = request.form.get('search_term','')
    results = Artist.query.filter(Artist.name.ilike('%'+search_term+'%'))
    response={
        "count": results.count(),
        "data": results
    }
    return render_template('pages/search_artists.html', results=response, search_term=request.form.get('search_term', ''))

@app.route('/artists/<int:artist_id>')
def show_artist(artist_id):
  artist = Artist.query.get(artist_id)
  return render_template('pages/show_artist.html', artist=artist)

#  ----------------------------------------------------------------
#  Update
#  ----------------------------------------------------------------
@app.route('/artists/<int:artist_id>/edit', methods=['GET'])
def edit_artist(artist_id):
    artist = Artist.query.get(artist_id)
    form = ArtistForm(obj=artist)
    return render_template('forms/edit_artist.html', form=form, artist=artist)

@app.route('/artists/<int:artist_id>/edit', methods=['POST'])
def edit_artist_submission(artist_id):
    error = False
    try:
        Artist.query.filter(Artist.id==artist_id).update({
            Artist.name:request.form.get('name'),
            Artist.city:request.form.get('city'),
            Artist.state:request.form.get('state'),
            Artist.phone:request.form.get('phone'),
            Artist.website:request.form.get('website'),
            Artist.image_link:request.form.get('image_link'),
            Artist.seeking_venue:request.form.get('seeking_venue')=='y',
            Artist.seeking_description:request.form.get('seeking_description'),
            Artist.facebook_link:request.form.get('facebook_link'),
            Artist.image_link:request.form.get('image_link'),
            Artist.genres:request.form.getlist('genre_list')
        })
        db.session.commit()
    except:
        error = True
        db.session.rollback()
    finally:
        db.session.close()
    if not error:
        flash("Artist Updated")
        return redirect(url_for('show_artist', artist_id=artist_id))
    # abort(500)
    flash("Error encountered")
    return redirect(url_for('edit_artist', artist_id=artist_id))


@app.route('/venues/<int:venue_id>/edit', methods=['GET'])
def edit_venue(venue_id):
    venue = Venue.query.get(venue_id)
    form = VenueForm(obj=venue)
    return render_template('forms/edit_venue.html', form=form, venue=venue)

@app.route('/venues/<int:venue_id>/edit', methods=['POST'])
def edit_venue_submission(venue_id):
    error = False
    try:
        Venue.query.filter(Venue.id==venue_id).update({
            Venue.name:request.form.get('name'),
            Venue.city:request.form.get('city'),
            Venue.state:request.form.get('state'),
            Venue.address:request.form.get('address'),
            Venue.phone:request.form.get('phone'),
            Venue.website:request.form.get('website'),
            Venue.image_link:request.form.get('image_link'),
            Venue.seeking_talent:request.form.get('seeking_talent')=='y',
            Venue.seeking_description:request.form.get('seeking_description'),
            Venue.facebook_link:request.form.get('facebook_link'),
            Venue.image_link:request.form.get('image_link'),
            Venue.genres:request.form.getlist('genre_list')
        })
        db.session.commit()
    except:
        error = True
        db.session.rollback()
    finally:
        db.session.close()
    if not error:
        flash("Venue Updated")
        return redirect(url_for('show_venue', venue_id=venue_id))
    # abort(500)
    flash("Error encountered")
    return redirect(url_for('edit_venue', venue_id=venue_id))


#  ----------------------------------------------------------------
#  Create Artist
#  ----------------------------------------------------------------

@app.route('/artists/create', methods=['GET'])
def create_artist_form():
  form = ArtistForm()
  return render_template('forms/new_artist.html', form=form)

@app.route('/artists/create', methods=['POST'])
def create_artist_submission():
    error = False
    try:
        data = {
            'name':request.form.get('name'),
            'city':request.form.get('city'),
            'state':request.form.get('state'),
            'phone':request.form.get('phone'),
            'website':request.form.get('website'),
            'image_link':request.form.get('image_link'),
            'seeking_venue':request.form.get('seeking_venue')=='y',
            'seeking_description':request.form.get('seeking_description'),
            'facebook_link':request.form.get('facebook_link'),
            'image_link':request.form.get('image_link'),
            'genres':request.form.getlist('genre_list')
        }
        new_artist = Artist(**data)
        db.session.add(new_artist)
        db.session.flush()
        new_artist_id = new_artist.id
        db.session.commit()
    except:
        error = True
        db.session.rollback()
    finally:
        db.session.close()
    if not error:
        flash('Artist ' + request.form['name'] + ' was successfully listed!')
        return redirect(url_for('show_artist', artist_id=new_artist_id))
    # abort(500)
    flash('An error occurred. Artist ' + data.name + ' could not be listed.')
    return render_template('pages/home.html')


#  ----------------------------------------------------------------
#  Shows
#  ----------------------------------------------------------------

@app.route('/shows')
def shows():
  shows = Show.query.all()
  return render_template('pages/shows.html', shows=shows)

@app.route('/shows/create')
def create_shows():
  form = ShowForm()
  return render_template('forms/new_show.html', form=form)

@app.route('/shows/create', methods=['POST'])
def create_show_submission():
    error = False
    try:
        data = {
            'artist_id':request.form.get('artist_id'),
            'venue_id':request.form.get('venue_id'),
            'start_time':request.form.get('start_time'),
        }
        new_show = Show(**data)
        db.session.add(new_show)
        db.session.commit()
    except:
        error = True
        db.session.rollback()
    finally:
        db.session.close()
    if not error:
        flash('Show was successfully listed!')
        return render_template('pages/home.html')
    flash('An error occurred. Show could not be listed.')
    return render_template('pages/home.html')

@app.errorhandler(404)
def not_found_error(error):
    return render_template('errors/404.html'), 404

@app.errorhandler(500)
def server_error(error):
    return render_template('errors/500.html'), 500


if not app.debug:
    file_handler = FileHandler('error.log')
    file_handler.setFormatter(
        Formatter('%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]')
    )
    app.logger.setLevel(logging.INFO)
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)
    app.logger.info('errors')

#----------------------------------------------------------------------------#
# Data Load Functions
#----------------------------------------------------------------------------#
def loadAllData():
    loadArtists()
    loadVenues()
    loadShows()

def loadArtists():
    # data requiring loading goes Here
    error = False
    artists = []
    data1={
    "id": 4,
    "name": "Guns N Petals",
    "genres": ["Rock n Roll"],
    "city": "San Francisco",
    "state": "CA",
    "phone": "326-123-5000",
    "website": "https://www.gunsnpetalsband.com",
    "facebook_link": "https://www.facebook.com/GunsNPetals",
    "seeking_venue": True,
    "seeking_description": "Looking for shows to perform at in the San Francisco Bay Area!",
    "image_link": "https://images.unsplash.com/photo-1549213783-8284d0336c4f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=300&q=80"
    }

    data2={
    "id": 5,
    "name": "Matt Quevedo",
    "genres": ["Jazz"],
    "city": "New York",
    "state": "NY",
    "phone": "300-400-5000",
    "facebook_link": "https://www.facebook.com/mattquevedo923251523",
    "seeking_venue": False,
    "image_link": "https://images.unsplash.com/photo-1495223153807-b916f75de8c5?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=334&q=80"
    }

    data3={
    "id": 6,
    "name": "The Wild Sax Band",
    "genres": ["Jazz", "Classical"],
    "city": "San Francisco",
    "state": "CA",
    "phone": "432-325-5432",
    "seeking_venue": False,
    "image_link": "https://images.unsplash.com/photo-1558369981-f9ca78462e61?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=794&q=80"
    }

    artists = [
        Artist(**data1),
        Artist(**data2),
        Artist(**data3),
        ]
    try:
        db.session.add_all(artists)
        db.session.commit()
        print("artists loaded")
    except:
        error = True
        print("artists data loading error")
    finally:
        db.session.close()


def loadVenues():
    # data requiring loading goes Here
    error = False
    venues = []
    data1={
        "id": 1,
        "name": "The Musical Hop",
        "genres": ["Jazz", "Reggae", "Swing", "Classical", "Folk"],
        "address": "1015 Folsom Street",
        "city": "San Francisco",
        "state": "CA",
        "phone": "123-123-1234",
        "website": "https://www.themusicalhop.com",
        "facebook_link": "https://www.facebook.com/TheMusicalHop",
        "seeking_talent": True,
        "seeking_description": "We are on the lookout for a local artist to play every two weeks. Please call us.",
        "image_link": "https://images.unsplash.com/photo-1543900694-133f37abaaa5?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=400&q=60"
    }

    data2={
        "id": 2,
        "name": "The Dueling Pianos Bar",
        "genres": ["Classical", "R&B", "Hip-Hop"],
        "address": "335 Delancey Street",
        "city": "New York",
        "state": "NY",
        "phone": "914-003-1132",
        "website": "https://www.theduelingpianos.com",
        "facebook_link": "https://www.facebook.com/theduelingpianos",
        "seeking_talent": False,
        "image_link": "https://images.unsplash.com/photo-1497032205916-ac775f0649ae?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80"
    }

    data3={
        "id": 3,
        "name": "Park Square Live Music & Coffee",
        "genres": ["Rock n Roll", "Jazz", "Classical", "Folk"],
        "address": "34 Whiskey Moore Ave",
        "city": "San Francisco",
        "state": "CA",
        "phone": "415-000-1234",
        "website": "https://www.parksquarelivemusicandcoffee.com",
        "facebook_link": "https://www.facebook.com/ParkSquareLiveMusicAndCoffee",
        "seeking_talent": False,
        "image_link": "https://images.unsplash.com/photo-1485686531765-ba63b07845a7?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=747&q=80"
    }

    venues = [
        Venue(**data1),
        Venue(**data2),
        Venue(**data3),
        ]
    try:
        db.session.add_all(venues)
        db.session.commit()
        print("venues loaded")
    except:
        error = True
        print("venues data loading error")
    finally:
        db.session.close()


def loadShows():
    # data requiring loading goes Here
    error = False
    shows = []
    data1={
        'artist_id': 4,
        'venue_id': 1,
        'start_time': '2019-05-21T21:30:00.000Z'
    }
    data2 = {
        'artist_id': 5,
        'venue_id': 3,
        'start_time': '2019-06-15T23:00:00.000Z',
    }
    data3 = {
        'artist_id': 6,
        'venue_id': 3,
        'start_time': '2035-04-01T20:00:00.000Z',
    }
    data4 = {
        'artist_id': 6,
        'venue_id': 3,
        'start_time': '2035-04-08T20:00:00.000Z',
    }
    data5 = {
        'artist_id': 6,
        'venue_id': 3,
        'start_time': '2035-04-15T20:00:00.000Z',
    }
    shows = [
        Show(**data1),
        Show(**data2),
        Show(**data3),
        Show(**data4),
        Show(**data5),
        ]
    try:
        db.session.add_all(shows)
        db.session.commit()
        print("shows loaded")
    except:
        error = True
        print("shows data loading error")
    finally:
        db.session.close()


#----------------------------------------------------------------------------#
# Launch.
#----------------------------------------------------------------------------#

# Default port:
if __name__ == '__main__':
    app.run()

# Or specify port manually:
'''
if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
'''
